(function (root, factory) {
  const api = factory();
  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  } else {
    root.JaneMediaUtils = api;
  }
}(typeof globalThis === "object" ? globalThis : this, function () {
  const DIRECT_EXTENSIONS = /\.(mp3|m4a|aac|ogg|oga|opus|wav|flac|weba|mp4|m4v|webm|mov|mkv|avi|flv|3gp|jpe?g|png|gif|webp|avif|heic)(?:[?#]|$)/i;
  const STREAM_EXTENSIONS = /\.(m3u8|mpd)(?:[?#]|$)/i;
  const RANGE_PARAMS = ["bytestart", "byteend", "range", "rn", "rbuf"];

  function classify(url, contentType) {
    const value = String(url || "");
    const type = String(contentType || "").toLowerCase();
    if (STREAM_EXTENSIONS.test(value) || type.includes("mpegurl") || type.includes("dash+xml")) {
      return "stream";
    }
    if (type.startsWith("video/")) return "video";
    if (type.startsWith("audio/")) return "audio";
    if (type.startsWith("image/")) return "image";
    const extension = /\.([a-z0-9]{2,5})(?:[?#]|$)/i.exec(value);
    if (!extension || !DIRECT_EXTENSIONS.test(value)) return null;
    if (/^(jpe?g|png|gif|webp|avif|heic)$/i.test(extension[1])) return "image";
    if (/^(mp3|m4a|aac|ogg|oga|opus|wav|flac|weba)$/i.test(extension[1])) return "audio";
    return "video";
  }

  function normalizeMediaUrl(url) {
    try {
      const parsed = new URL(url);
      let wasRanged = false;
      for (const parameter of RANGE_PARAMS) {
        if (parsed.searchParams.has(parameter)) {
          parsed.searchParams.delete(parameter);
          wasRanged = true;
        }
      }
      return { url: parsed.toString(), wasRanged };
    } catch (_) {
      return { url: String(url || ""), wasRanged: false };
    }
  }

  function isStreamSegment(url, contentType) {
    const value = String(url || "");
    const type = String(contentType || "").toLowerCase();
    return /\.(ts|m4s)(?:[?#]|$)/i.test(value)
      || /\/videoplayback\b|googlevideo\.com\//i.test(value)
      || /[/_-](seg|segment|chunk|frag)[-_/.]?\d/i.test(value)
      || /segment/i.test(type);
  }

  function isSocialMediaImage(url) {
    const value = String(url || "");
    return /\.(jpe?g|png|gif|webp|svg|ico|bmp|avif|heic)(?:[?#]|$)/i.test(value)
      || (/fbcdn\.net\//i.test(value) && /\/[ps]\d{2,4}x\d{2,4}\//i.test(value));
  }

  function filenameFromUrl(url, kind, index) {
    try {
      const path = new URL(url).pathname.split("/").pop() || "";
      const clean = decodeURIComponent(path)
        .replace(/[^a-z0-9._-]+/gi, "-")
        .replace(/^-+|-+$/g, "");
      if (clean && /\.[a-z0-9]{2,5}$/i.test(clean)) return clean.slice(-180);
    } catch (_) {}
    const extension = kind === "image" ? "jpg" : kind === "audio" ? "mp3" : "webm";
    return "browser-capture-" + (Number(index) + 1) + "." + extension;
  }

  function selectCaptureItems(items, mode, maxItems) {
    const unique = new Map();
    for (const item of Array.isArray(items) ? items : []) {
      if (!item || !item.mediaKind) continue;
      const key = item.mediaUrl || (item.mediaKind + ":" + item.frameId + ":" + item.elementIndex);
      if (!unique.has(key)) unique.set(key, item);
    }
    return Array.from(unique.values())
      .filter(function (item) {
        return item.mediaKind !== "video" || item.captureable !== false || !item.mediaUrl;
      })
      .sort(function (left, right) {
        return Number(Boolean(right.playing)) - Number(Boolean(left.playing))
          || Number(Boolean(right.visible)) - Number(Boolean(left.visible))
          || Number(Boolean(right.size || 0)) - Number(Boolean(left.size || 0));
      })
      .slice(0, mode === "sequence" ? maxItems : 1);
  }

  return {
    classify,
    filenameFromUrl,
    isSocialMediaImage,
    isStreamSegment,
    normalizeMediaUrl,
    selectCaptureItems
  };
}));
